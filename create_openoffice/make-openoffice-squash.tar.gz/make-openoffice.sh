#!/bin/sh

[ ! -f /usr/local/bin/unzipper ] && echo Unzipper not installed! && exit

SOURCE=$(ls *.gz 2>/dev/null)
[ -z "$SOURCE" ] && echo OpenOffice source package not found! && exit

LANGCODE=${SOURCE##*_}
LANGCODE=${LANGCODE%.tar.gz}
[ -z "$LANGCODE" ] && echo Language code not identified! && exit
SQUASH=${SOURCE%install-deb_*}${LANGCODE}.squashfs

echo In the next step, Unzipper will run.
echo  You will extract the OpenOffice source into /tmp
read -p "Press Enter to start: "

rm -rf /tmp/$LANGCODE
unzipper $SOURCE

dpkg -i /tmp/$LANGCODE/DEBS/*.deb  #into /opt/openoffice4

rm -rf /opt/build
mkdir -p /opt/build/opt
mv /opt/openoffice4 /opt/build/opt

rm -f $SQUASH
mksquashfs /opt/build $SQUASH

cp /tmp/en-GB/DEBS/desktop-integration/*.deb .	#this is the menu setup file

rm -rf /opt/build
rm -rf /tmp/$LANGCODE
echo Done!
